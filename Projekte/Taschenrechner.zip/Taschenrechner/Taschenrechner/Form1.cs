﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Taschenrechner
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
       

        double ErsteZahl;
        string Operatoren;

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            // lässt nur zu das Zahlen, Operatoren und Punkt eingegeben werden


            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                (e.KeyChar != ',' && e.KeyChar != '+' && e.KeyChar != '-' && e.KeyChar != '*' && e.KeyChar != '/'))
            {
                e.Handled = true;
            }

            

        }

        private void btn1_Click(object sender, EventArgs e)
        {
            textBox1.Text += "1";
        }

       

        private void btn0_Click(object sender, EventArgs e)
        {
            textBox1.Text += "0";

        }

        private void btn2_Click(object sender, EventArgs e)
        {
            textBox1.Text += "2";
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            textBox1.Text += "3";
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            textBox1.Text += "4";
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            textBox1.Text += "5";
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            textBox1.Text += "6";
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            textBox1.Text += "7";
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            textBox1.Text += "8";
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            textBox1.Text += "9";
        }

        private void btnGleich_Click(object sender, EventArgs e)
        {

            double ZweiteZahl;
            double Ergebnis;

            if (textBox1.Text == "")
            {
                return;
            }

            ZweiteZahl = Convert.ToDouble(textBox1.Text);

            if (Operatoren == "+")
            {
                Ergebnis = (ErsteZahl + ZweiteZahl);
                textBox1.Text = Convert.ToString(Ergebnis);
                ErsteZahl = Ergebnis;
            }
            if (Operatoren == "-")
            {
                Ergebnis = (ErsteZahl - ZweiteZahl);
                textBox1.Text = Convert.ToString(Ergebnis);
                ErsteZahl = Ergebnis;
            }
            if (Operatoren == "*")
            {
                Ergebnis = (ErsteZahl * ZweiteZahl);
                textBox1.Text = Convert.ToString(Ergebnis);
                ErsteZahl = Ergebnis;
            }
            if (Operatoren == "/")
            {
                if (ZweiteZahl == 0)
                {
                    return;

                }
                else
                {
                    Ergebnis = (ErsteZahl / ZweiteZahl);
                    textBox1.Text = Convert.ToString(Ergebnis);
                    ErsteZahl = Ergebnis;
                }
            }



         
        }

        private void btnPlus_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "") 
            {
                return;
              
            }
            else
            {
                ErsteZahl = Convert.ToDouble(textBox1.Text);
                textBox1.Text = "";
                Operatoren = "+";
            }



        }

        private void btnMinus_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "") 
            {
                return;
              
            }
            else
            {
                ErsteZahl = Convert.ToDouble(textBox1.Text);
                textBox1.Text = "";
                Operatoren = "-";
            }
        }

        private void btnMal_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "") 
            {
                return;
            
            }
            else
            {
                ErsteZahl = Convert.ToDouble(textBox1.Text);
                textBox1.Text = "";
                Operatoren = "*";
            }
        }

        private void btnGeteilt_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "") 
            {
                return;
             
            }
            else
            {
                ErsteZahl = Convert.ToDouble(textBox1.Text);
                textBox1.Text = "";
                Operatoren = "/";
            }

            
        }

        private void btnAC_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        
        }

        private void btnKomma_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "") 
            {
                return;
                
            }
            else
            {
                textBox1.Text = textBox1.Text + ",";

                
                if (textBox1.Text.Contains(",,"))
                {
                    
                    textBox1.Text = textBox1.Text.Replace(",,",",");
                    return;
                 
                }

              
                int Komma = 0;
                for (int i = 0; i < textBox1.Text.Length; i++) 
                {
                    if (textBox1.Text[i] == ',')
                    {
                        Komma++;
                        if (Komma > 1)
                        {
                            textBox1.Text = textBox1.Text.Remove(i, 1);
                            i--;
                            Komma--;
                        }
                    }
                }
                textBox1.Text = textBox1.Text;
                textBox1.Select(textBox1.Text.Length, 0);


            }

        }
    }
}
